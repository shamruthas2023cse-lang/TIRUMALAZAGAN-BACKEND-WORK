from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import SessionLocal
from models import User
from schemas import UserCreate, UserLogin, UserProfile
from auth import hash_password, verify_password, create_token

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/register")
def register(user: UserCreate, db: Session = Depends(get_db)):
    hashed = hash_password(user.password)
    new_user = User(username=user.username, email=user.email, password=hashed)
    db.add(new_user)
    db.commit()
    return {"message": "Registered successfully"}

@router.post("/login")
def login(user: UserLogin, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.email == user.email).first()
    if not db_user or not verify_password(user.password, db_user.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token({"user_id": db_user.id})
    return {"access_token": token}

@router.post("/profile/{user_id}")
def update_profile(user_id: int, profile: UserProfile, db: Session = Depends(get_db)):
    user = db.query(User).get(user_id)
    user.age = profile.age
    user.contact = profile.contact
    db.commit()
    return {"message": "Profile updated"}
