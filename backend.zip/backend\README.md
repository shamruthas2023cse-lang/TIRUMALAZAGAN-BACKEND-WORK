# Backend — Exam Verification API

Quick notes to run and develop the FastAPI backend used by the project.

Prerequisites
- Python 3.9+ (project used 3.12 in this workspace virtualenv)
- git (optional)

Setup (one-time)
```powershell
# from repository root
python -m venv .venv
.\.venv\Scripts\activate
pip install -r backend\requirements.txt
```

Run (development)
```powershell
# run the backend (binds to 0.0.0.0 so frontends can access it)
python -m uvicorn main:app --app-dir backend --host 0.0.0.0 --port 8000
```

Quick test (curl)
```powershell
curl http://127.0.0.1:8000/verify/logo
```

Notes
- The local DB is configured to use SQLite (`backend/database.py`) for easy local development: `sqlite:///./exam_verify.db`.
- To use Postgres, replace `DATABASE_URL` in `backend/database.py` with your DSN (or use an env var) and ensure the DB server and database exist.
- CORS: development uses a permissive CORS policy in `backend/main.py`. Restrict `allow_origins` for production.
- Auth: password hashing uses `bcrypt` (installed as `bcrypt==4.0.1` for compatibility). Tokens are JWTs using `python-jose`.

Useful endpoints
- `GET /verify/logo` — verification example
- `POST /register` — register a user (json: `username,email,password`)
- `POST /login` — login (json: `email,password`)

Stopping the server
- Press `Ctrl+C` in the terminal running uvicorn.

If you want, I can:
- Add environment variable support (`python-dotenv`) and `.env.example`.
- Add Alembic migrations for Postgres.